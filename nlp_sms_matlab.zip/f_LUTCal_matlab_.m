function [Z_Pos, X_Dif, ZX_DelayTable, Aperture_Table] = f_LUTCal_matlab_(RawData, Parameters, NumSampleOffset)

X_Dif = zeros(2*Parameters.NumScanline - 1, 1);
% Z_Pos = zeros(Parameters.NumDepthSample*Parameters.factor_interp, 1);
EndDepthSample = Parameters.ImgDepthSample*Parameters.factor_interp;
Z_Pos = zeros(EndDepthSample, 1);

NumScanline = single(size(RawData,2));
NumDepthSample = single(Parameters.NumDepthSample*Parameters.factor_interp);
NumSampleOffset_interp = NumSampleOffset*Parameters.factor_interp;
%% set X_Dif
X_Dif(1:NumScanline - 1, 1) = linspace((NumScanline-1) * Parameters.Pitch, 1 * Parameters.Pitch, NumScanline-1);
X_Dif(NumScanline:2*NumScanline - 1, 1) = linspace(0, (NumScanline - 1) * Parameters.Pitch, NumScanline);

%% set Z_Pos
% Z_Pos(1:NumDepthSample, 1) = linspace(1 * Parameters.AxialStep_interp, NumDepthSample * Parameters.AxialStep_interp, NumDepthSample);
Z_Pos(1:EndDepthSample, 1) = linspace(1 * Parameters.AxialStep_interp, EndDepthSample * Parameters.AxialStep_interp, EndDepthSample);
%% make ZX_DelayTable
X_temp = repmat(X_Dif', size(Z_Pos));
Z_temp = repmat(Z_Pos, size(X_Dif'));
if (strcmp(Parameters.mode, 'US'))
   ZX_DelayTable = (Z_temp + sqrt(X_temp.^2 + Z_temp.^2)) / Parameters.AxialStep_interp + NumSampleOffset_interp;
   ZX_DelayTable(ZX_DelayTable >= NumDepthSample) = NumDepthSample;
elseif (strcmp(Parameters.mode, 'PA'))
   ZX_DelayTable = sqrt(X_temp.^2 + Z_temp.^2) / Parameters.AxialStep_interp + NumSampleOffset_interp;
   ZX_DelayTable(ZX_DelayTable >= NumDepthSample) = NumDepthSample;
else
    fprintf('Wrong Mode input');
end

%% make Aperture Table
tap_base = 7;
angle = atan(X_temp./Z_temp);
if (strcmp(Parameters.ApertureControl, 'on'))
    Aperture_Table = double(angle <= Parameters.Accep_angle);
elseif ((strcmp(Parameters.ApertureControl, 'off')))
    Aperture_Table = double(ones(size(angle)));
else
    fprintf('Wrong ApertureControl input');
end
Aperture_Table(:, (-floor(tap_base/2):floor(tap_base/2)) + NumScanline) = 1;

%% Apodization Table
if strcmp(Parameters.Apodization, 'on')
    element_number = sum(Aperture_Table, 2);
    for i = 1:size(Aperture_Table,1)
        window_temp = hamming(element_number(i,1))';
        Aperture_Table(i, NumScanline + (-floor(element_number(i,1)/2):floor(element_number(i,1)/2))) = ...
            window_temp;
    end
end