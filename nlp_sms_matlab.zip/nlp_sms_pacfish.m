%% Compile mexcuda file before execution
%mexcuda -v '-LC:\Program Files\NVIDIA GPU Computing Toolkit\CUDA\v11.5\lib\x64' -lcufft -largeArrayDims STFT_psc.cu

%% file load
% Loading time should be quite long. So, if you want to use existing data
% in workspace, set load_newfile = 'no'
clear;
close all;

[hdf5_filename, hdf5_filepath] = uigetfile('C:\Users\SMS\OneDrive - postech.ac.kr\바탕 화면\Verasonics\DAS_예제\파일굽기\Sample\.hdf5');
h_info = h5info(fullfile(hdf5_filepath, hdf5_filename)); %% choose hdf5 file

[binary_data, meta_acquisition, meta_device] = pacfish.load_data(fullfile(hdf5_filepath, hdf5_filename));

%% setting menu
Parameters.ApertureControl = 'on'; %% on, off
Parameters.Apodization = 'off'; %% on, off
Parameters.F_cut_left = single(1e6); % unit: Hz, for DC_cancel_filter
% Parameters.F_cut_right = single(14e6);

if nonzeros(contains(fieldnames(meta_device.detectors.deleteme0000000000), 'frequency_response'))
    Parameters.Fc = single(meta_device.detectors.deleteme0000000000.frequency_response(1)); %unit: Hz, for Bandpass filtering & IQ demodulation
    Parameters.Fbw = single(meta_device.detectors.deleteme0000000000.frequency_response(1)...
        *meta_device.detectors.deleteme0000000000.frequency_response(2)/2); %unit: Hz, for Bandpass filtering & IQ demodulation
else
    Parameters.Fc = input('What is the center frequency of transducer [MHz]: ') * 1e6;
    Parameters.Fbw = input('What is the fractional bandwidth of transducer [%]: ') * Parameters.Fc / 100 / 2;
end

Parameters.DemodType = 'hilbert'; %% IQ, hilbert
beamforming_method = 'DAS'; %% DAS, nlp_sms
Parameters.Accep_angle = single(30*(pi/180)); %rad, you need to modify this part according to the system


%% fixed Parameters
NumSampleOffset = 1.3021*4; %% unit: number of delayed sample, you need to modify this part according to the system
Parameters.NumScanline = double(meta_device(1).general.num_detectors);
Parameters.NumDepthSample = double(meta_acquisition.sizes(1));
% Parameters.ImgDepthSample = Parameters.NumDepthSample/2;
Parameters.Fs = single(meta_acquisition.ad_sampling_rate); %Hz
% Parameters.SoS = single(Resource.Parameters.speedOfSound); % 1450 for US phantom, 1500 for custom phantom
Parameters.SoS = single(meta_acquisition.speed_of_sound);
Parameters.factor_interp = 4;
Parameters.factor_decim = 4;
Parameters.Ts = 1/Parameters.Fs;
Parameters.Pitch = single((meta_device.detectors.deleteme0000000001.detector_position(1) - ...
    meta_device.detectors.deleteme0000000000.detector_position(1))); % m
Parameters.AxialStep = Parameters.Ts*Parameters.SoS; %m
Parameters.AxialStep_interp = Parameters.AxialStep / Parameters.factor_interp; %m


Parameters.ImgDepthSample = ceil((meta_device.general.field_of_view(6) - meta_device.general.field_of_view(5)) /...
    Parameters.AxialStep);

Parameters.mode = 'PA'; %% US, PA
Parameters.pth = 2;
if ~strcmp(beamforming_method, 'DMAS'), Parameters.pth = 1; end



%% RawData reorder
RawData = binary_data;

%% RawData DC cancel filtering
RawData_DC_cancel = f_DC_Cancel(RawData, Parameters);
%% RawData interpolation for fs > 16*fc
RawData_interp_temp1 = f_interpolation(RawData_DC_cancel, Parameters);
%% STFT
if strcmp(beamforming_method, 'nlp_sms')
RawData_interp_temp2 = single(RawData_interp_temp1);
w = single(hann(256));
%     w = single(ones(256,1));
p = 2;
RawData_interp = STFT_psc(RawData_interp_temp2,w,0.75,p);
elseif strcmp(beamforming_method, 'DAS')
p = 1;
RawData_interp = single(RawData_interp_temp1);
end

%% Delay Table Calculation
[Z_Pos, X_Dif, ZX_DelayTable, Aperture_Table] = f_LUTCal_matlab_(RawData_interp, Parameters, NumSampleOffset);
%% Delay and Sum Beamforming
P_interp = f_beamforming_matlab_(ZX_DelayTable, Aperture_Table, RawData_interp, Parameters, beamforming_method);

%% BPF before demodulation
% if strcmp(demodtype, 'IQ') || strcmp(beamforming_method, 'DMAS')
if strcmp(Parameters.DemodType, 'IQ')
    P_interp_BPF = f_BPF_matlab_(Parameters, P_interp);
% elseif strcmp(demodtype, 'hilbert') && strcmp(beamforming_method, 'DAS')
elseif strcmp(Parameters.DemodType, 'hilbert')
	P_interp_BPF = P_interp;
%     P_interp_BPF = f_BPF_matlab_(Parameters, P_interp);
else
    frprint('Invalid demodtpye');
end
%% Demdulation
P_demod_temp = f_Demodulation_matlab_(Parameters, P_interp_BPF);
P_demod = P_demod_temp.^p;

%% Decimation
P_decim = f_Decimation_matlab_(Parameters, P_demod) * (1 + strcmp(Parameters.DemodType, 'IQ'));
P_decim(P_decim<0) = 0;


%% image show
NumScanline = size(P_decim,2);

close all;
f1 = figure(1);
ax1 = axes;
img1 = imagesc(ax1, [X_Dif(NumScanline + 1), X_Dif(end)]*1e3, [Z_Pos(1), Z_Pos(end)]*1e3, P_decim/max(P_decim(:)));
caxis(ax1, [0, 0.1]);
axis(ax1, 'image');
xlabel('Lateral Position [mm]', 'fontsize',16);
ylabel('Depth [mm]','fontsize',16);
% ylim(ax1, [0, (meta_device.general.field_of_view(6) - meta_device.general.field_of_view(5))]);
colormap(hot(256));
