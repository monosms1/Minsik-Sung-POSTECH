function P_decim = f_Decimation_matlab_(Parameters, P_demod)

P_temp = zeros(size(P_demod, 1)/Parameters.factor_decim, size(P_demod, 2));

for i = 1:size(P_demod,2)
    P_temp(:,i) = decimate(double(P_demod(:,i)), Parameters.factor_decim, 'fir');
end
P_decim = P_temp;

end