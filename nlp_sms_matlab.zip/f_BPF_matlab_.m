function P_interp_BPF = f_BPF_matlab_(Parameters, P_interp)
    factor_bandstop = 0.9;
    f_center = Parameters.Fc * (2 - rem(Parameters.pth, 2));
    f_cut_left = (f_center - Parameters.Fbw)/(Parameters.Fs*Parameters.factor_interp/2);
    f_cut_right = (f_center + Parameters.Fbw)/(Parameters.Fs*Parameters.factor_interp/2);
    f = [0, f_cut_left*factor_bandstop, f_cut_left,f_cut_right, f_cut_right*(2-factor_bandstop), 1];
    mag = [0, 0, 1, 1, 0, 0];
    BPF = fir2(300, f,mag)';

    P_interp_BPF = conv2(P_interp, BPF, 'same');
end