function P = f_beamforming_matlab_(ZX_DelayTable, Aperture_Table, RawData, Parameters, beamforming_method)

if strcmp(beamforming_method, 'DAS') || strcmp(beamforming_method, 'nlp_sms')
    NumDepthSample = single(Parameters.NumDepthSample*Parameters.factor_interp);
    EndDepthSample = double(Parameters.ImgDepthSample*Parameters.factor_interp);
    NumScanline = size(RawData, 2);
    
    offset_table = repmat(NumDepthSample*(0:NumScanline-1),EndDepthSample, 1);
    P = zeros(EndDepthSample, Parameters.NumScanline);
    for i= 0 : NumScanline - 1
        P(:,i+1) = sum(RawData(round(ZX_DelayTable(:, NumScanline - i:NumScanline*2 - 1 - i)) + offset_table) ...
            .* Aperture_Table(:, NumScanline - i:NumScanline*2 - 1 - i), 2);
    end
elseif strcmp(beamforming_method, 'DMAS')
    NumDepthSample = single(Parameters.NumDepthSample*Parameters.factor_interp);
    EndDepthSample = Parameters.ImgDepthSample*Parameters.factor_interp;
    
    offset_table = repmat(NumDepthSample*(0:Parameters.NumScanline-1),EndDepthSample, 1);
    P = zeros(EndDepthSample, Parameters.NumScanline);
    for i= 0 : Parameters.NumScanline - 1
        DelayedData = RawData(round(ZX_DelayTable(:, Parameters.NumScanline - i:Parameters.NumScanline*2 - 1 - i)) + offset_table);
        root_data = sign(DelayedData).* nthroot(abs(DelayedData), Parameters.pth);
        P(:,i+1) = (sum(root_data ...
            .* Aperture_Table(:, Parameters.NumScanline - i:Parameters.NumScanline*2 - 1 - i), 2)).^Parameters.pth;
    end
end

